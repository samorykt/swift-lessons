//
//  main.swift
//  PracticalTask04
//
import SwiftUI
import Foundation

enum TransmissionType: String {
    case automatic = "АКПП"
    case manual = "МКПП"
}

enum MethodAcceleration: String {
    case fast = "быстрый разгон"
    case turbine = "разгон с турбиной"
}

enum MethodOfUnloadingOfCargo: String {
    case automatic = "автоматическая выгрузка груза (самосвал)"
    case manual = "ручная выгрузка груза (грузчики)"
}

class Car {
    var model: String
    var yearOfIssue: Int
    var color: Color
    var transmission: TransmissionType
    var powerHorse: Int
    
    init (model: String, yearOfIssue: Int, color: Color, transmission: TransmissionType, powerHorse: Int) {
        self.model = model
        self.yearOfIssue = yearOfIssue
        self.color = color
        self.transmission = transmission
        self.powerHorse = powerHorse
    }
}

class SportCar: Car {
    var acceleration: MethodAcceleration
    
    init (model: String, yearOfIssue: Int, color: Color, transmission: TransmissionType, powerHorse: Int, acceleration: MethodAcceleration) {
        self.acceleration = acceleration
        super.init(model: model, yearOfIssue: yearOfIssue, color: color, transmission: transmission, powerHorse: powerHorse)
    }
    
    func accelerationTo100_km_h() {
        if acceleration == .fast {
            print("Машина \(model) - \(yearOfIssue) г.в. разогнался до 100 км/ч за 5 сек., т.к. без турбины")
        } else {
            print("Машина \(model) - \(yearOfIssue) г.в. разогнался до 100 км/ч за 3.5 сек., т.к. c турбиной")
        }
    }
}

class TrunkCar: Car {
    var unloadingOfCargo: MethodOfUnloadingOfCargo
    
    init (model: String, yearOfIssue: Int, color: Color, transmission: TransmissionType, powerHorse: Int, unloadingOfCargo: MethodOfUnloadingOfCargo) {
        self.unloadingOfCargo = unloadingOfCargo
        super.init(model: model, yearOfIssue: yearOfIssue, color: color, transmission: transmission, powerHorse: powerHorse)
    }
    
    func unloadingCargo() {
        print("Грузовик \(model) - \(yearOfIssue) г.в. подъехал на разгрузку.")
        print("Сейчас будет \(unloadingOfCargo.rawValue)")
    }
}

var sportCars = [SportCar]() // спорткары
sportCars.append(SportCar(model: "Audi R8", yearOfIssue: 2018, color: .blue, transmission: .manual, powerHorse: 550, acceleration: .fast))
sportCars.append(SportCar(model: "Ferrari F40", yearOfIssue: 2016, color: .red, transmission: .manual, powerHorse: 478, acceleration: .turbine))

var trunkCars = [TrunkCar]() // грузовики
trunkCars.append(TrunkCar(model: "МАЗ-5551", yearOfIssue: 2009, color: .gray, transmission: .manual, powerHorse: 230, unloadingOfCargo: .automatic))
trunkCars.append(TrunkCar(model: "Toyota Dyna", yearOfIssue: 2016, color: .white, transmission: .automatic, powerHorse: 180, unloadingOfCargo: .manual))

for i in 0..<sportCars.count { // выводим значения свойств спортивных машин
    print("Марка авто №\(i+1): \(sportCars[i].model)")
    print("Год выпуска: \(sportCars[i].yearOfIssue)")
    print("Цвет кузова: \(sportCars[i].color)")
    print("Коробка передач: \(sportCars[i].transmission.rawValue)")
    print("Мощность двигателя, в л.с.: \(sportCars[i].powerHorse)")
    if sportCars[i].acceleration == .turbine {
        print("Наличие турбины: Есть")
    } else {
        print("Наличие турбины: Нет")
    }
    print()
}

for i in 0..<trunkCars.count { // выводим значения свойств грузовых машин
    print("Марка авто №\(i+1): \(trunkCars[i].model)")
    print("Год выпуска: \(trunkCars[i].yearOfIssue)")
    print("Цвет кузова: \(trunkCars[i].color)")
    print("Коробка передач: \(trunkCars[i].transmission.rawValue)")
    print("Мощность двигателя, в л.с.: \(trunkCars[i].powerHorse)")
    if trunkCars[i].unloadingOfCargo == .automatic {
        print("Самосвал: Да")
    } else {
        print("Самосвал: Нет")
    }
    print()
}
print()

for i in 0..<sportCars.count {
    if sportCars[i].acceleration == .fast {
        sportCars[i].accelerationTo100_km_h()
    } else {
        sportCars[i].accelerationTo100_km_h()
    }
    print()
}
print()

for i in 0..<trunkCars.count {
    if trunkCars[i].unloadingOfCargo == .automatic {
        trunkCars[i].unloadingCargo()
    } else {
        trunkCars[i].unloadingCargo()
    }
    print()
}
print()

//
//  ViewController.swift
//  PracticalTask_UI_01
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var login: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let hideAction = UITapGestureRecognizer(target: self, action: #selector(Hidekeyboard))
        
        view.addGestureRecognizer(hideAction)

    }

    @objc func Hidekeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func pressButton(_ sender: UIButton) {
        guard let loginInput = login.text, !loginInput.isEmpty else {
            welcomeLabel.textColor = .red
            welcomeLabel.text = "Введите логин!"
            return
        }
        guard let pwdInput = password.text, !pwdInput.isEmpty else {
            welcomeLabel.textColor = .red
            welcomeLabel.text = "Введите пароль!"
            return
        }
        welcomeLabel.textColor = .yellow
        welcomeLabel.text = "Добро пожаловать!" }
        
    }

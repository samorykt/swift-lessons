//
//  main.swift
//  PracticalTask_03

import Foundation

enum EngineState: String {
    case start = "запущен"
    case stop = "заглушен"
}
    
enum WindowsState: String {
    case open = "открыты"
    case closed = "закрыты"
}

enum ActionOverCargo: String {
    case load = "загрузить"
    case upload = "выгрузить"
}

struct Car {
    var model: String
    var yearOfIssue: Int
    var volumeOfTrunk: Int
    var engineState: EngineState {
        willSet {
            if newValue == .start {
                print("заведется двигатель...")
            } else {
                print("остановится двигатель...")
            }
        }
    }
    var windowsState: WindowsState {
        willSet {
            if newValue == .open {
                print("откроются окна...")
            } else {
                print("закроются окна...")
            }
        }
    }
    var volumeCargo: Int
    
    mutating func actionOfEngine(action: EngineState) {
        switch action {
        case .start:
            self.engineState = .start
        case .stop:
            self.engineState = .stop
        }
    }
    
    mutating func actionOfWindows(action: WindowsState) {
        switch action {
        case .open:
            self.windowsState = .open
        case .closed:
            self.windowsState = .closed
        }
    }
    
    mutating func actionOverCargo(action: ActionOverCargo, volume: Int) {
        switch action {
        case .load:
            if (volumeCargo + volume) < volumeOfTrunk {
                self.volumeCargo = volumeCargo + volume
            } else {
                print("В багажник/кузов столько не влезет!")
                return
            }
        case .upload:
            if volume < 0 || volume > volumeCargo {
                print("Недопустимый объем груза для отгрузки")
            } else {
                self.volumeCargo = volumeCargo - volume
            }
        }
    }
   
    init(model: String, yearOfIssue: Int, volumeOfTrunk: Int, engineState: EngineState, windowsState: WindowsState, volumeCargo: Int) {
        self.model = model
        self.yearOfIssue = yearOfIssue
        self.volumeOfTrunk = volumeOfTrunk
        self.engineState = engineState
        self.windowsState = windowsState
        self.volumeCargo = volumeCargo
    }
}

var cars = [Car]()
cars.append(Car(model: "Toyota Allion", yearOfIssue: 2007, volumeOfTrunk: 50, engineState: .start, windowsState: .closed, volumeCargo: 0))
cars.append(Car(model: "Mazda Titan", yearOfIssue: 1997, volumeOfTrunk: 300, engineState: .stop, windowsState: .open, volumeCargo: 200))

for i in 0..<cars.count { // выводим начальные свойства
    print("Марка авто №\(i+1): \(cars[i].model)")
    print("Год выпуска: \(cars[i].yearOfIssue)")
    print("Объем багажника/кузова: \(cars[i].volumeOfTrunk)")
    print("Состояние двигателя: \(cars[i].engineState.rawValue)")
    print("Состояние окон: \(cars[i].windowsState.rawValue)")
    if cars[i].volumeCargo != 0 {
        print("Багажник/кузов загружен. Объем груза равен \(cars[i].volumeCargo)")
    }
    print()
    print()
}

for i in 0..<cars.count {
    print("У машины \(cars[i].model) - \(cars[i].yearOfIssue) г.в. сейчас ", terminator: "")
    if cars[i].engineState == .start { // если двигатель запущен, то останавливаем
        cars[i].actionOfEngine(action: .stop)
    } else {                           // иначе - заводим
        cars[i].actionOfEngine(action: .start)
    }
    print("Текущее состояние двигателя: \(cars[i].engineState.rawValue)")
    print()

    print("У машины \(cars[i].model) - \(cars[i].yearOfIssue) г.в. сейчас ", terminator: "")
    if cars[i].windowsState == .open { // если окна открыты, то закрываем
        cars[i].actionOfWindows(action: .closed)
    } else {                           // иначе - открываем
        cars[i].actionOfWindows(action: .open)
    }
    print("Текущее состояние окон: \(cars[i].windowsState.rawValue)")
    print()

    print("Начальное значение объема груза: \(cars[i].volumeCargo)")
    if cars[i].volumeCargo == 0 { // если багажник/кузов пустой, то загружаем груз (с проверкой)
        let volumeLoad = 30
        print("Загружаем \(volumeLoad) объема груза")
        cars[i].actionOverCargo(action: .load, volume: volumeLoad)
    } else {                      // иначе - выгружаем (с проверкой)
        let volumeUpload = 150
        print("Выгружаем \(volumeUpload) объема груза")
        cars[i].actionOverCargo(action: .upload, volume: volumeUpload)
    }
    print("Текущее значение объема груза: \(cars[i].volumeCargo)")
    print()
    print()
}

